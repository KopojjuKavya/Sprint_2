package com.cg.otm.controller;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;
import com.cg.otm.dto.Question;
import com.cg.otm.service.QuestionService;
@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class QuestionController 
{
	@Autowired
	QuestionService questionService;
	public void setQuestionService(QuestionService questionService)
	{
		this.questionService=questionService;
	}
	 @GetMapping(value="/getQuestion/{QuestionId}", produces="application/json")
	  public ResponseEntity<Optional<Question>> getQuestion(@PathVariable int QuestionId)
	  {
		   Optional<Question> question = questionService.getQuestion(QuestionId);
		   if(question.isPresent())
			   return new ResponseEntity<Optional<Question>>(question,HttpStatus.OK);
		   return new ResponseEntity<Optional<Question>>(question,HttpStatus.NOT_FOUND);
	  }
	
   @GetMapping(value="/getQuestions",produces="application/json")
   public List<Question> getQuestions()
   {
	   return questionService.getQuestions();
   }
   

  /* @PostMapping(value="/addQuestion",consumes="application/json")
   public ResponseEntity<String> insertQuestion(@RequestBody()Question question)
   {
	   String message="Question inserted successfully";
	   if(questionService.insertQuestion(question)==null)
		   message="Question insertion failed";
	   return new ResponseEntity<String>(message,HttpStatus.BAD_REQUEST);
   }
   
   @PutMapping(value="/updateQuestion",consumes="application/json")
   public String updateQuestion(@RequestBody()Question question)
   {
	   String message=questionService.updateQuestion(question);
	   return message;
   }*/
   @DeleteMapping("/deleteQuestion/{QuestionId}")
   public ResponseEntity<String> deleteQuestion(@PathVariable int QuestionId)
   {
	   try
	   {
		   questionService.deleteQuestion(QuestionId);
		   return new ResponseEntity<String>("Question Details Deleted Successfully",HttpStatus.OK);
	   }
	   catch(Exception ex)
	 	  {
	 		 return new ResponseEntity<String>("Deletion Failed",HttpStatus.BAD_REQUEST);
	 	  }
   }
 /*  @GetMapping("/getMarks")
   public void getMarks()
   {
 	      ArrayList<Integer>  choose = new ArrayList<Integer>();
 	      ArrayList<Question> ans= (ArrayList<Question>)questionService.getQuestions();
 	      ArrayList<Question> marks = new ArrayList<Question>();
 	      ans.addAll(questionService.methodanswer());
 	      int s=questionService.methodanswer().size();
 	      System.out.println(s);
 	      choose.addAll(questionService.methodchoose());
 	      marks.addAll(questionService.methodmarks());
 	      int c=ans.size();
 	      System.out.println(c);
 	      int total=0;
 	      for(int i=0;i<c;i++)
 	      {
 	    	  if(ans.get(i)==choose.get(i))
 	    	  {
 	    		  total=total+marks.get(i);
 	    	  }
 	      }
 	      System.out.println("The marks you have obtained are: "+total);
   }*/
}

  







