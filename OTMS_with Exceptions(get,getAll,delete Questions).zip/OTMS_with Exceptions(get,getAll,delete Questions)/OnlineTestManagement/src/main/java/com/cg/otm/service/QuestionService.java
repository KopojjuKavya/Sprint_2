package com.cg.otm.service;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.cg.otm.dao.QuestionDAO;
import com.cg.otm.dto.Question;
@Service
public class QuestionService 
{
	@Autowired
    QuestionDAO qdao;
    public void setqdao(QuestionDAO qdao) { this.qdao=qdao;}
    
   /* @Transactional
    public Question insertQuestion(Question question)
    {
        return qdao.save(question);
    }*/
    
    @Transactional
    public Optional<Question> getQuestion(int QuestionId)
    {
    	return qdao.findById(QuestionId);
    }
    
    @Transactional(readOnly=true)
    public List<Question> getQuestions()
    {
    	return qdao.findAll();
    }
  /*  @Transactional
    public String updateQuestion(Question newQuestion)
    {
    	Question question= qdao.findById(newQuestion.getQuestionId()).get();
    	if(question!=null)
    	{
    	 question.setQuestionContent(newQuestion.getQuestionContent());
    	 question.setOption1(newQuestion.getOption1());
    	 question.setOption2(newQuestion.getOption2());
    	 question.setOption3(newQuestion.getOption3());
    	 question.setMarks(newQuestion.getMarks());
    	 question.setAnswerOption(newQuestion.getAnswerOption());
    	  return "Question Modified";
    	}
    	return "Update Failed";
    }*/
    @Transactional
    public String deleteQuestion(int QuestionId)
    {
    	qdao.deleteById(QuestionId);
    	return "Question Deleted";
    }
   /* public ArrayList<Integer> QuestionId=new ArrayList<Integer>();
	public ArrayList<String> QuestionContent=new ArrayList<String>();
	public ArrayList<String> Option1=new ArrayList<String>();
	public ArrayList<String> Option2=new ArrayList<String>();
	public ArrayList<String> Option3=new ArrayList<String>();
	public ArrayList<Question> Marks=new ArrayList<Question>();
	public ArrayList<Question> AnswerOption=new ArrayList<Question>();
	public ArrayList<Integer> choosen_answer=new ArrayList<Integer>();
@Transactional
public ArrayList<Integer> methodanswer()
{
Statement st = null;
try
{
	  @SuppressWarnings("null")
	ResultSet rs=st.executeQuery("select * from question");
	  while(rs.next())
	  {
		  QuestionId.add(rs.getInt(1));
		  QuestionContent.add(rs.getString(2));
		  Option1.add(rs.getString(3));
		  Option2.add(rs.getString(4));
		  Option3.add(rs.getString(5));
		  Marks.add(rs.getInt(6), null);
	  }
	  ResultSet rs1=st.executeQuery("select * from question");
		 while(rs1.next())
		 {
			 AnswerOption.add(rs1.getInt(7), null);
		 }
			}
			catch(Exception e)
			{
				System.out.println(e);
			}
			return AnswerOption;
		}
@Transactional
public  ArrayList<Question> methodmarks()
	{
		return Marks;
		
	}
@Transactional
public ArrayList<Integer> methodchoose()
	{
		int count=QuestionId.size();
		for(int i=0;i<count;i++)
		{
	       System.out.println(QuestionId.get(i)+")"+QuestionContent.get(i));
	       System.out.println("Options:");
	       System.out.println("1."+Option1.get(i)+"\n"+"2."+Option2.get(i)+"\n"+"3."+Option3.get(i));
	       @SuppressWarnings("resource")
		   Scanner sc=new Scanner(System.in);
	       int a=sc.nextInt();
	       choosen_answer.add(a);       	
	}
		return choosen_answer;
	}*/
    
}
